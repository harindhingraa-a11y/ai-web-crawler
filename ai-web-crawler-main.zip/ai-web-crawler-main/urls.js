export const URLS = [
  'https://www.wifh.com/laser-tattoo-removal/',
  'https://www.wifh.com/skin/coolpeel/'
];
